The directory that contains this file should be placed in a subdirectory of the directory that contains the game files START.EXE, GAME.OVR, etc.

For the GoG versions, that is C:\Program Files (x86)\GOG Galaxy\Games\Pool of Radiance\POOLRAD by default.

This patch applies to the v.1.3 of Pool of Radiance that is distributed by GoG.

To apply the patch, run the patch.bat file which will execute the hpatchz.exe to patch the binary files in the parent directory with the binary diffs in this directory.